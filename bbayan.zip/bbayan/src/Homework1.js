import React, { useState, useCallback } from 'react';
import './Homework1.css';

const Homework1 = () => {
    const colors = ['black', 'red', 'orange', 'yellow', 'green'];
    const [number, setNumber] = useState(0);

    const increaseNumber = useCallback(() => {
        setNumber(prevNumber => (prevNumber + 1) % colors.length);
    }, [colors.length]);

    return (
        <div className="homework1-container">
            <h2 style={{ color: colors[number] }}>{number}</h2>
            <button onClick={increaseNumber}>+</button>
        </div>
    );
};

export default Homework1;
