import React, { useState } from 'react';
import './Homework2.css';

const images = [
    {
        "id":1,
        "img":"https://i.ibb.co/XW7Xzyy/car-expert-1.jpg",
        "name":"John Hopkins",
        "expertise":"Engine Expert"
     },
     {
        "id":2,
        "img":"https://i.ibb.co/r5dpKZh/car-expert-2.jpg",
        "name":"Lucas Burke",
        "expertise":"Painting Expert"
     },
     {
        "id":3,
        "img":"https://i.ibb.co/3BVJBG9/car-expert-3.jpg",
        "name":"Joel Henderson",
        "expertise":"Tire-Repair Expert"
     },
     {
        "id":4,
        "img":"https://i.ibb.co/V3xCZ2r/car-expert-4.jpg",
        "name":"Louie Griffiths",
        "expertise":"Car-Brake Expert"
     },
     {
        "id":5,
        "img":"https://i.ibb.co/xhG387F/car-expert-5.jpg",
        "name":"Paul Noel",
        "expertise":"Car-Tuning Expert"
     }
];

const Homework2 = () => {
    const [index, setIndex] = useState(0);

    const prevImage = () => {
        setIndex((index - 1 + images.length) % images.length);
    };

    const nextImage = () => {
        setIndex((index + 1) % images.length);
    };

    return (
        <div className="homework2-container">
            <div className="gallery">
                <img src={images[index].url} alt={`Image ${index + 1}`} />
            </div>
            <button onClick={prevImage}>BACK</button>
            <button onClick={nextImage}>NEXT</button>
        </div>
    );
};

export default Homework2;
